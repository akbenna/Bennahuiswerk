# Benne Health assets — opgeschoonde set

Wat hier staat is de bruikbare helft van `benne-health-assets-v1.zip`, bijgesneden
en op maat gezet. Wat er niet in staat is bewust weggelaten; waarom staat onderaan.

## Wat er is gebeurd

De originele bestanden zijn uitsnedes van een contactvel, geen exports. In vrijwel
elk bestand zat het bijschrift ingebrand (`icon_add.png`, `bg_hills.png`, in
`button_primary.png` zelfs de mapnaam `12_buttons`), plus een flard van de
buurtegel en de rand van de kaart eronder. Bij de voedselfoto's besloeg het
onderwerp 38 tot 69 procent van het bestand; de rest was leegte en ruis.

Per bestand is het onderwerp opgezocht, de ingebrande tekst en de randflarden zijn
verwijderd, en het resultaat is vierkant gecentreerd met 6 tot 12 procent marge.

| map | aantal | formaat | achtergrond |
|---|---|---|---|
| `01_logo` | 2 | 512 × 512 | wit |
| `02_navigation` | 10 | 96 × 96 | transparant |
| `03_actions` | 8 | 96 × 96 | transparant |
| `04_status` | 4 | 96 × 96 | transparant |
| `08_food` | 10 | 512 × 512 | wit |
| `14_empty_states` | 3 | 384 × 384 | wit |
| `15_misc` | 5 | 96 × 96 | transparant |

`02_navigation/nav_today.png` is met de hand bijgesneden en verdient nog een blik:
het huisje stond als enige tegen de kaartrand aan.

## Wat er niet in zit, en waarom

**`05_categories`, `06_goals`, `07_health_illustrations` (19 bestanden).** Dit zijn
emoji-glyphs op formaat getrokken — 🥣 🥗 🎯 🧠 🫀 🫁 🫃 — geen eigen illustraties.
Het beeldmateriaal van Apple-emoji is niet vrij te verspreiden, en de anatomische
exemplaren zeggen in een gezondheidsapp iets wat de app niet waarmaakt.

**`09_progress`, `10_charts`, `11_badges`, `12_buttons` (16 bestanden).** Dit zijn
plaatjes van de interface, geen assets: `progress_calories.png` is een ring met
"1.640 van 2.100 kcal" er ingebakken. Die cijfers zijn levend en horen in SVG
getekend te worden, niet als PNG ingeladen.

**`13_backgrounds` (4 bestanden).** Wel op te schonen, maar decoratieve landschappen
achter getallen kosten contrast en leesbaarheid.

## Voor productie

De `design_tokens.json` zegt het zelf: dit is een eerste extractie en er hoort een
tweede stap achter met echte SVG-mastericonen. Dat klopt — op 96 px zijn deze
iconen zichtbaar zacht aan de randen en ze zijn niet te hertinten.

Let ook op de kleuren in `design_tokens.json`: `primary #2E7D32` en
`secondary #4CAF50` zijn de Material-groenen. De app draait op `--k #07785C` en
`--kfel #10A87E`. Eén van de twee moet wijken, anders vloekt elk groen icoon met
elke groene ring.
